# Project Art avatar-sequence finalization

This boundary completes the evidence handoff between an explicit Art Studio avatar-sequence mastering plan and the parser-ready `evavo_avatar_sequence_pack_v2` consumed by `@evavo/avatar-runtime` 0.7.0.

It does not generate or edit an image. It does not infer animation meaning. It does not approve its own output, activate a runtime sequence, create a release seal, mutate a repository, commit, push, deploy, or publish.

## Why finalization is two-phase

The mastering compiler intentionally emits an incomplete runtime draft:

```text
review: null
loopClosures: []
runtimeActivationAllowed: false
```

A reviewer cannot safely approve a subject whose exact loop evidence or copied target bytes are still changing. Finalization therefore uses two create-only phases.

### Phase 1: prepare an exact review subject

`prepare` validates and binds:

- the exact `evavo.project-art-avatar-sequence-mastering-plan.v1` document;
- the compiled `evavo_art_workspace_file_plan_v1` and applied `evavo_art_workspace_file_receipt_v1` when reviewed copies were required;
- every reviewed target PNG by path, SHA-256, byte count, canvas, alpha channel and stable file metadata;
- one request, plan, review and receipt chain for every true loop;
- the exact final-to-first seam, ordered frame identities, thresholds and measured metrics;
- the byte-identical validated loop producer implementation pinned at Art Studio commit `37b3cdd0c1ed403880379534744c0528d65cab16`;
- the target runtime commit `68bbd1fbf91bfcac8f17c5148a34f82400ebed11` and package version `0.7.0`.

The output contract is:

```text
evavo.project-art-avatar-sequence-review-subject.v1
```

Its `documentSha256` is the exact subject that art, animation and runtime reviewers must approve independently.

### Phase 2: finalize a parser-ready candidate

`finalize` accepts a sealed review that binds the exact review-subject SHA-256. It requires exactly three approvals in this order:

```text
art
animation
runtime
```

Each approval must use a different reviewer identity, bind the same review-subject SHA-256, carry its own approval SHA-256 and occur no later than the sealed review time.

Before producing a candidate, the finalizer repeats all external evidence and target-frame validation. A stale target, replaced receipt, changed loop metric or altered review subject fails closed.

Every approval timestamp must follow the exact review-subject preparation time and precede the sealed review time. The finalizer also revalidates the pinned loop compiler limits, execution contract, preview policy, expected canvas, frame metadata and threshold set rather than accepting a merely self-hashed lookalike plan.

The output contract is:

```text
evavo.project-art-avatar-sequence-candidate.v1
```

It contains a parser-ready sequence pack and its canonical SHA-256, but still states:

```text
runtimeActivationAllowed: false
releaseSealRequired: true
```

A separate `evavo_avatar_sequence_release_v1` seal remains mandatory before an application may activate the sequence.

## Review-subject request

```json
{
  "schema": "evavo.project-art-avatar-sequence-review-subject-request.v1",
  "subjectId": "eva-female-sequence-subject-v1",
  "masteringPlan": {
    "path": "evidence/eva/mastering-plan.json",
    "expectedSha256": "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
  },
  "workspaceEvidence": {
    "plan": {
      "path": "evidence/eva/workspace-plan.json",
      "expectedSha256": "1123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
    },
    "receipt": {
      "path": "evidence/eva/workspace-receipt.json",
      "expectedSha256": "2123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
    }
  },
  "loopEvidence": [
    {
      "clipId": "idle-main",
      "request": {
        "path": "evidence/eva/idle/request.json",
        "expectedSha256": "3123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      },
      "plan": {
        "path": "evidence/eva/idle/plan.json",
        "expectedSha256": "4123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      },
      "review": {
        "path": "evidence/eva/idle/output/loop-closure.json",
        "expectedSha256": "5123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      },
      "receipt": {
        "path": "evidence/eva/idle/output/receipt.json",
        "expectedSha256": "6123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      }
    }
  ],
  "authority": {
    "semanticAssignment": false,
    "creativeApproval": false,
    "animationApproval": false,
    "runtimeApproval": false,
    "releaseSeal": false,
    "providerExecution": false,
    "sourceMutation": false,
    "sourceDeletion": false,
    "targetImageWrite": false,
    "repositoryMutation": false,
    "gitCommit": false,
    "gitPush": false,
    "publication": false,
    "deployment": false,
    "forcePush": false
  }
}
```

When the mastering plan required no copies, `workspaceEvidence` must be `null`. Supplying false workspace evidence is rejected.

## Prepare from the command line

```powershell
node scripts/finalize-project-art-avatar-sequence.mjs prepare `
  --workspace-root C:\GitRepos\evavo-avatar-runtime `
  --request C:\GitRepos\evavo-avatar-runtime\evidence\eva\review-subject-request.json `
  --output C:\GitRepos\evavo-avatar-runtime\evidence\eva\review-subject.json `
  --prepared-at 2026-08-11T10:10:00.000Z
```

The output path must be inside the workspace and must not already exist.

## Sealed finalization request

```json
{
  "schema": "evavo.project-art-avatar-sequence-finalization-request.v1",
  "finalizationId": "eva-female-sequence-finalization-v1",
  "reviewSubject": {
    "path": "evidence/eva/review-subject.json",
    "expectedSha256": "7123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
  },
  "review": {
    "status": "sealed",
    "reviewId": "eva-female-sequence-review-v1",
    "subjectSha256": "8123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
    "decisionSha256": "9123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
    "sealedAt": "2026-08-11T10:14:00.000Z",
    "approvals": [
      {
        "discipline": "art",
        "reviewerId": "reviewer-art",
        "approvedAt": "2026-08-11T10:11:00.000Z",
        "subjectSha256": "8123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
        "approvalSha256": "a123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      },
      {
        "discipline": "animation",
        "reviewerId": "reviewer-animation",
        "approvedAt": "2026-08-11T10:12:00.000Z",
        "subjectSha256": "8123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
        "approvalSha256": "b123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      },
      {
        "discipline": "runtime",
        "reviewerId": "reviewer-runtime",
        "approvedAt": "2026-08-11T10:13:00.000Z",
        "subjectSha256": "8123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
        "approvalSha256": "c123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      }
    ]
  },
  "authority": {
    "semanticAssignment": false,
    "creativeApproval": false,
    "animationApproval": false,
    "runtimeApproval": false,
    "releaseSeal": false,
    "providerExecution": false,
    "sourceMutation": false,
    "sourceDeletion": false,
    "targetImageWrite": false,
    "repositoryMutation": false,
    "gitCommit": false,
    "gitPush": false,
    "publication": false,
    "deployment": false,
    "forcePush": false
  }
}
```

## Finalize from the command line

```powershell
node scripts/finalize-project-art-avatar-sequence.mjs finalize `
  --workspace-root C:\GitRepos\evavo-avatar-runtime `
  --request C:\GitRepos\evavo-avatar-runtime\evidence\eva\finalization-request.json `
  --output C:\GitRepos\evavo-avatar-runtime\evidence\eva\candidate.json `
  --finalized-at 2026-08-11T10:15:00.000Z
```

## Callable ChatGPT or Claude boundary

Start the dedicated MCP server:

```powershell
$env:EVAVO_ART_AVATAR_SEQUENCE_FINALIZER_ROOTS = "C:\GitRepos\evavo-avatar-runtime;C:\EVAVO\staging"
$env:EVAVO_ART_AVATAR_SEQUENCE_FINALIZER_MCP_ALLOW_WRITE = "true"
node C:\GitRepos\evavo-art-studio\tools\project_art_avatar_sequence_finalizer_mcp.mjs
```

It exposes:

```text
evavo_art_avatar_sequence_finalization_capabilities
evavo_art_prepare_avatar_sequence_review_subject
evavo_art_finalize_avatar_sequence_candidate
```

MCP receives paths and bounded JSON summaries, not source-image bytes. The subprocess environment is credential-redacted and uses `shell: false`.

See `config/mcp.project-art-avatar-sequence-finalizer.windows.example.json`.

## Cross-runtime document hashes

The loop review and receipt are produced by the pinned Python/Pillow runner. Python preserves integral floating-point lexemes such as `1.0`, while JavaScript normally serializes that value as `1`. The finalizer verifies Python document hashes from the original JSON numeric lexemes instead of silently recalculating a different JavaScript hash.

## Fail-closed behavior

The finalizer rejects:

- request-object and request-byte substitution;
- missing or false workspace evidence;
- incomplete or reordered loop evidence;
- request, plan, review or receipt hash drift;
- a blocked loop review or non-empty issue list;
- frame-order, seam, threshold or metric substitution;
- stale or replaced reviewed target PNGs;
- missing source revalidation or non-atomic loop publication;
- duplicate reviewers, missing disciplines or approval-time reversal;
- approvals bound to another subject;
- any provider, source, image, repository, Git, deployment, publication or force-push authority;
- output replay into an existing subject or candidate path.

## Authority boundary

The finalizer validates supplied approval evidence; it does not perform approval. It prepares a runtime-compatible candidate; it does not activate or release it.

No image generation, image editing, source mutation, provider execution, approval, release sealing, repository mutation, Git operation, deployment or publication authority is granted by this boundary.
